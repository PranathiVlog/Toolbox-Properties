﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PanelControl
{
    public partial class Form1 : Form
    {
        List<Panel> ListPanel = new List<Panel>();
        int index;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            if (index < ListPanel.Count - 1)
                ListPanel[++index].BringToFront();
        }

        private void btnprevious_Click(object sender, EventArgs e)
        {
            if (index > 0)
                ListPanel[--index].BringToFront();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ListPanel.Add(panel1);
            ListPanel.Add(panel2);
            ListPanel.Add(panel3);
            ListPanel[index].BringToFront();
        }
    }
}
